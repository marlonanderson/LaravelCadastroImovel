
<tbody>
    @foreach($imoveis as $imovel)
        <tr>
            <td>{{$imovel->descricao}}</td>
            <td>{{$imovel->cidadeEndereco}}</td>
            <td>{{$imovel->preco}}</td>
            <td>{{$imovel->finalidade}}</td>
            <td>{{$imovel->tipo}}</td>
            <td>
                <a href="#"><i class="glyphicon glyphicon-pencil"></i></a>
                <a href="#"><i class="glyphicon glyphicon-trash"></i></a>
                <a href="#"><i class="glyphicon glyphicon-zoom-in"></i></a>
            </td>
        </tr>
    @endforeach
</tbody>
<a href="{{route('imoveis.create')}}"><button class="btn btn-primary">Adicionar</button></a>
